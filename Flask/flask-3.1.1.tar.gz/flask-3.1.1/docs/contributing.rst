Contributing
============

See the Pallets `detailed contributing documentation <_contrib>`_ for many ways
to contribute, including reporting issues, requesting features, asking or
answering questions, and making PRs.

.. _contrib: https://palletsprojects.com/contributing/
