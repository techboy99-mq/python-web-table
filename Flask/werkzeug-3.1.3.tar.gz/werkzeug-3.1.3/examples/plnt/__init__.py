"""A planet application, pronounced "plant"."""
from .webapp import Plnt
