"""Very simple wiki application based on Genshi, Werkzeug and
SQLAlchemy. Additionally the creoleparser is used for the wiki markup.
"""
from .application import SimpleWiki
