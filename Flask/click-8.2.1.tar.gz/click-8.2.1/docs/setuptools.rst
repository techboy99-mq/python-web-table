:orphan:

Setuptools Integration
======================

Moved to :doc:`entry-points`.
